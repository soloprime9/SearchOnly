@echo off
title StickMotion AI — 1-Click Studio Launcher (Windows)
color 0b
echo ==============================================================================
echo           ⚡ STICKMOTION AI — 1-CLICK STUDIO LAUNCHER (WINDOWS)
echo ==============================================================================
echo Checking system requirements...

:: Check Python
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Python is not installed or not in PATH!
    echo Please install Python 3.10+ from python.org and check "Add Python to PATH".
    pause
    exit /b
)

:: Check and install dependencies
echo Installing required AI audio & video modules (zero-cost stack)...
pip install -q edge-tts pillow moviepy requests gradio

echo.
echo ==============================================================================
echo [SUCCESS] StickMotion AI Environment Ready!
echo Starting local creative director studio...
echo ==============================================================================

:: Open browser
start http://localhost:7860
python -m gradio 01_MOBILE_STUDIO_ANDROID_IOS\Google_Colab_1Click_Mobile_Studio.ipynb

pause
