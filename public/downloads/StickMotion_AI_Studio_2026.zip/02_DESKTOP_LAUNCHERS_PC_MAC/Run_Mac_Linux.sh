#!/bin/bash
# ==============================================================================
# StickMotion AI — 1-Click Studio Launcher (macOS & Linux)
# ==============================================================================

echo "=============================================================================="
echo "          ⚡ STICKMOTION AI — 1-CLICK STUDIO LAUNCHER (MAC / LINUX)"
echo "=============================================================================="

# Check Python
if ! command -v python3 &> /dev/null
then
    echo "[ERROR] Python 3 is not installed. Please install Python 3.10+."
    exit 1
fi

echo "Installing required AI audio & video modules (zero-cost stack)..."
pip3 install -q edge-tts pillow moviepy requests gradio

echo "=============================================================================="
echo "[SUCCESS] Environment ready! Launching studio..."
echo "=============================================================================="

python3 -m gradio 01_MOBILE_STUDIO_ANDROID_IOS/Google_Colab_1Click_Mobile_Studio.ipynb
