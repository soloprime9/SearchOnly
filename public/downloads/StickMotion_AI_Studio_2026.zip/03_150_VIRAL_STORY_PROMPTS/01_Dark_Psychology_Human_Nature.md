# 🧠 35 High-Retention Psychology & Human Behavior Scripts
### Tested Retention Hooks, Scene Beat Maps & Stickman Visual Prompts

---

## 📜 Master Story Framework (The "Curiosity Loop" Formula)
Every viral psychology script follows this strict 45-second retention timeline:
* **00s - 03s [The Pattern Interrupt Hook]:** A counter-intuitive statement that forces the viewer to stop scrolling.
* **03s - 15s [The Relatable Flaw]:** Showing why the viewer or most people suffer from this psychological trap.
* **15s - 35s [The Stickman Story / Experiment]:** A quick 2-scene metaphorical story illustrating the phenomenon.
* **35s - 45s [The Insight & Actionable CTA]:** The shocking takeaway and a reason to follow/share.

---

### Script 1: The Psychology of "The Quietest Person in the Room"
* **Hook (0-3s):** "Notice how the smartest person in any meeting is always the one speaking the least?"
* **Voiceover (4-25s):** "In 1999, psychologists Cornell and Dunning proved that incompetent people are burdened with excess confidence, while intelligent people constantly question their own knowledge. When a room gets chaotic, an amateur rushes to talk. But a master listens — because you can't learn anything while your mouth is moving."
* **Story Beat & Visuals (26-45s):**
  * *Scene 1:* Stickman A jumping up and down with giant speech bubbles full of exclamation marks.
  * *Scene 2:* Stickman B sitting calm with crossed arms, glowing lightbulb above head, taking notes.
* **Stickman Prompt:** `A minimalist 2D black stickman sitting calmly with arms crossed on a white background, observant expression, clean linework, high contrast vector style --ar 9:16`

---

### Script 2: The "Spotlight Effect" (Why Nobody Actually Cares About Your Mistakes)
* **Hook (0-3s):** "You made a fool of yourself yesterday, and you think everyone is still laughing. Here's why you're completely wrong."
* **Voiceover (4-25s):** "Psychologists call it the Spotlight Effect. We instinctively overestimate how much other people notice our appearance and blunders by over 400%. The truth? People aren't judging you — they're too busy worrying about how you're judging them."
* **Story Beat & Visuals (26-45s):**
  * *Scene 1:* Stickman walking under a giant intense theater spotlight, sweating and anxious.
  * *Scene 2:* Camera zooms out to show 5 other stickmen looking at their own phones, completely ignoring him.
* **Stickman Prompt:** `A 2D stickman character sweating under an overhead spotlight, cartoon expression, surrounded by stickmen looking at smartphones, black and white minimal line art --ar 9:16`

---

### Script 3: The Paradox of Procrastination
* **Hook (0-3s):** "You're not lazy. Your brain is just terrified of not being perfect."
* **Voiceover (4-25s):** "Procrastination isn't a time management problem; it's an emotional regulation problem. When a task feels overwhelming, your amygdala triggers a threat response identical to seeing a predator. Scrolling your phone is just your brain fleeing the tiger."
* **Story Beat & Visuals (26-45s):**
  * *Scene 1:* Stickman staring at a giant looming mountain of papers.
  * *Scene 2:* Stickman running away to sofa and scrolling glowing phone screen with guilty eyes.
* **Stickman Prompt:** `A stickman running away in panic from a stack of giant papers, landing on a small sofa with a glowing phone, minimal white background, expressive lines --ar 9:16`

---

*(Vault contains 32 additional fully formatted scripts covering: The Pratfall Effect, Cognitive Dissonance, The 5-Second Rule, Dark Triad Charisma, The Pygmalion Effect, and more).*
