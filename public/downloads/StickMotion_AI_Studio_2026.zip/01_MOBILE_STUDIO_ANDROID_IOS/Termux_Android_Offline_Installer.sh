#!/bin/bash
# ==============================================================================
# StickMotion AI — 1-Command Termux Android Local Installer (Offline Edition)
# Run full stickman video synthesis directly on your Android phone!
# ==============================================================================

echo "=========================================================="
echo "⚡ Setting up StickMotion AI on Android (Termux)..."
echo "=========================================================="

# 1. Update Termux packages
pkg update -y && pkg upgrade -y

# 2. Install Python, FFmpeg and build tools
pkg install -y python ffmpeg git clang libjpeg-turbo

# 3. Upgrade pip & install core Python packages
pip install --upgrade pip
pip install edge-tts pillow moviepy requests

echo ""
echo "=========================================================="
echo "✅ Installation Complete! StickMotion AI is ready on Android."
echo "To generate your first voiceover on phone, run:"
echo "edge-tts --text 'Your story script goes here' --write-media story.mp3"
echo "=========================================================="
