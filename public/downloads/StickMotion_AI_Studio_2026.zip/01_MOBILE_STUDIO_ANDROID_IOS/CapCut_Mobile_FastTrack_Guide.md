# 📱 Android & iPhone CapCut Mobile Fast-Track Guide
### How to Produce a Viral Stickman Reel on Your Phone in Under 3 Minutes

---

## 🎯 Overview
90% of creators on Instagram and TikTok use their smartphones. You do **NOT** need a laptop or PC to make professional stickman storytelling shorts. Using CapCut mobile (free on Android and iOS) and our prompt presets, you can create a complete video from scratch in 3 minutes.

---

## ⚡ The 3-Minute Production Workflow

### Step 1: Generate the Script (30 seconds)
1. Open ChatGPT, Claude, or Gemini in your phone browser.
2. Open any script from `03_150_VIRAL_STORY_PROMPTS/`.
3. Copy the 45-second script with scene breakdown.

---

### Step 2: Generate Free Natural Voiceover on Mobile (45 seconds)
* **Method A (Inside CapCut Mobile — Easiest):**
  1. Open CapCut > Tap **New Project** > Select a dark background or texture.
  2. Tap **Text** > **Add text** > Paste your entire script.
  3. Tap **Text to Speech** at the bottom menu.
  4. Choose dynamic voices like **"Narrator"**, **"Energetic Male"**, or **"Storyteller"**. CapCut generates natural audio instantly!
  5. Delete the text layer (the voice audio layer remains on your timeline).

* **Method B (Free Edge-TTS via Phone Browser):**
  1. Go to any free Edge-TTS web interface or our Colab cloud link.
  2. Pick *en-US-ChristopherNeural* or *en-US-GuyNeural*.
  3. Download the MP3 directly to your phone downloads folder.
  4. In CapCut: Tap **Audio** > **Sounds** > Tap the folder icon > Select your downloaded MP3.

---

### Step 3: Add Stickman Overlays (45 seconds)
1. In CapCut, tap **Overlay** > **Add overlay**.
2. Select your stickman clip or transparent PNG image.
3. **If using a Green-Screen clip:**
   * Tap the stickman clip on your timeline.
   * Scroll bottom tools and tap **Cutout** (or **Remove BG**).
   * Tap **Chroma key** > Drag the color picker circle to the green area.
   * Increase **Intensity** to 50–70% and **Shadow** to 30%. The green disappears completely, leaving only the clean stickman!
4. **If using a white/black background image:**
   * Tap **Blend** > Select **Filter** (removes black) or **Multiply** (removes white).

---

### Step 4: Add Keyframe Animations (Make Stickman Move!)
1. Tap the stickman overlay on your timeline.
2. Tap the **Keyframe button (◆+)** next to the Play button.
3. Move the playhead forward by 1 second.
4. Drag or scale the stickman on your preview screen with two fingers. CapCut automatically creates smooth motion between keyframes!

---

### Step 5: 1-Tap Auto-Captions (The Retention Secret)
1. Tap **Text** > **Auto captions**.
2. Select **Dynamic captions** (e.g., glowing yellow, bold white, or Hormozi pop style).
3. Tap **Generate** — CapCut automatically synchronizes the text with your audio.
4. Place the text in the middle third of your screen so mobile UI buttons don't block it.

---

### Step 6: Add SFX & Lo-Fi Music (30 seconds)
1. Tap **Audio** > **Effects** > search for **"whoosh"** or **"pop"** whenever the stickman appears.
2. Tap **Audio** > **Sounds** > choose a chill lo-fi beat.
3. **Crucial:** Lower background music volume to **10% - 15%** so your voiceover is loud, crisp, and clear.

---

### 🚀 Step 7: Export & Post
* Top right corner: Set resolution to **1080p** and frame rate to **30fps** or **60fps**.
* Tap **Export** -> Save directly to your Android Gallery.
* Post with the high-RPM hashtags from `06_FACELESS_MONETIZATION_BLUEPRINT/`.
